﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LogicLib
{
	public enum _Quarter
	{
		第一季度 = 1,
		第二季度 = 2,
		第三季度 = 3,
		第四季度 = 4,
	}
}
